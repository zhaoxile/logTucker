%% =================================================================
% This script runs the FCTN decomposition-based TC method
%
% More detail can be found in [1]
% [1] Teng-Yu Ji, Ting-Zhu Huang ∗, Xi-Le Zhao ∗, Tian-Hui Ma, Liang-Jian Deng
%     A non-convex tensor rank approximation for tensor completion
%
% Please make sure your data is in range [0, 1].
%
% Created by Teng-Yu Ji (tengyu_j66@126.com)
% Jun. 08, 2016
% Updated by Teng-Yu Ji
% Apr. 18, 2021
% function Demo

%%
addpath(genpath('data'));
addpath(genpath('lib'));
clear; 
close all; 

%%
load('suzie_qcif.mat')
X_tensorTrue = X/255; 
Nway = size(X_tensorTrue);

sr = 0.3;  
p = round(sr*prod(Nway));   
Omega = randsample(prod(Nway),p); data = X_tensorTrue(Omega);
[Omega, id]= sort(Omega); data= data(id);
B= zeros(Nway); B(Omega)= data;

%% 
tol = 1e-5;
maxit = 500;

alpha = [1, 1, 1];
alpha = alpha / sum(alpha);
opts.alpha=alpha;

%% Logdet
epsilon = 5e-5; 
beta = 10; 
[X_L, real_L, res_L, time_L, rank_L, Iter_L] = LRTC_logTucker(B, Omega, alpha, beta, tol, maxit, epsilon, X_tensorTrue);

[psnr, ssim]          = quality_ybz(X_tensorTrue*255, X_L*255);
fprintf('\n');
fprintf('================== Result =====================\n');
fprintf(' %8.8s    %5.4s    %5.4s    \n','method','PSNR', 'SSIM' );
fprintf(' %8.8s    %5.3f    %5.3f    \n',   'logDet', psnr, ssim);


