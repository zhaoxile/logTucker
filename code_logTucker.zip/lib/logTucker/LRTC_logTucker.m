function [X_tensor, real, res, time, rank_his, Iter] = LRTC_logTucker(B, Omega, alpha, beta, tol, maxit, epsilon, X_tensorTrue)
%% Initialization
rank_his = [];
tic
Nway = size(B);
N = length(Nway);
X_tensor = B; 
X_tensor(logical(1-Omega)) = mean(B(Omega)); %%���ʼ�����еĶ�ʧ������������ֵƽ����
for n = 1 : N
    M_tensor{n} = zeros(Nway);
    Lambda_tensor{n} = zeros(Nway);
end
real = [];
%% main loop
for k = 1 : maxit
    beta = beta * 1.05;
    
    %%% to solve the W problem (auxiliary variable)
    %%begin W problem
    tau = alpha/beta;
    for n = 1 : N
        if k <= 0
            Z = Unfold(X_tensor + Lambda_tensor{n}/beta, Nway, n);
            M{n} = Pro2TraceNorm(Z, tau(n));
            M_tensor{n} = Fold(M{n}, Nway, n);
        else
            temp2 = Unfold(M_tensor{n}, Nway, n);
            w{n} = svd(temp2);
            w{n} = w{n} + epsilon;
            w{n} = 1./w{n};
            Z = Unfold(X_tensor + Lambda_tensor{n}/beta, Nway, n);
            M{n} = Pro2TraceNorm_logdet(Z, tau(n)*w{n});
            M_tensor{n} = Fold(M{n}, Nway, n);
        end
    end
    %%end W problem
    
    %%% to solve the X_tensor problem
    %%begin X_tensor problem
    X_tensorOld = X_tensor;
    M_sum = 0; Lambda_sum = 0;
    for n = 1 : N
        M_sum = M_sum + M_tensor{n};
        Lambda_sum = Lambda_sum + Lambda_tensor{n};
    end
    X_tensor = (beta*M_sum - Lambda_sum)/(N*beta);
    X_tensor(Omega) = B(Omega);
    %%end X_tensor problem
    
    %%% check the convergence
    if nargin == 10
        real(k) = norm(X_tensor(:) - X_tensorTrue(:)) / norm(X_tensorTrue(:));
    end
    res(k) = norm(X_tensor(:) - X_tensorOld(:)) / norm(X_tensorOld(:));
    if mod(k, 10) == 0
        fprintf('TC_with_logdet: iterations = %d   difference=%f\n', k, res(k));
    end
    if res(k) < tol && k>20
        break;
    end
    
    %%% update the Lagrange multiplier
    for n = 1 : N
        Lambda_tensor{n} = Lambda_tensor{n} +  beta*(X_tensor - M_tensor{n}); %% 1.618 and update beta can not be at the same time
    end
end
time = toc;
Iter = k;
fprintf('TC_with_logdet ends: total iterations = %d   difference=%f\n', k, res(k));